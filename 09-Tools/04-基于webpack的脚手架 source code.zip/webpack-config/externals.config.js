module.exports = {
  jquery: 'window.jQuery',
};
