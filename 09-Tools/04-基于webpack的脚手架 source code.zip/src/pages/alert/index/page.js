require('cp');
$(() => {

});
