require('cp');

$(() => {
});
