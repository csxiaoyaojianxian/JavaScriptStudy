var mapper = require('../../lib/mapper');
window.mapper =  mapper;
