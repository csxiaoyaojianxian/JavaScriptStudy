# csxiaoyao.js
csxiaoyao封装的常用工具类库
[www.csxiaoyao.com](http://www.csxiaoyao.com)